myxlab <- "Carat"
myylab <- "Price"
mymain <- "Diamonds are Sparkly!"