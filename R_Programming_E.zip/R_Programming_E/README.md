# R Programming with Email Notification

## Installation

```r
library(swirl)
install_course_github("swirldev", "R_Programming_E")
swirl()
```

### Manual Installation

1. Download [this](https://github.com/swirldev/R_Programming_E/raw/master/R_Programming_E.swc) file.
2. Run `swirl::install_course()` in the R console.
3. Select the file you just downloaded.

## Help

See http://swirlstats.com/, open an issue, or email info@swirlstats.com.