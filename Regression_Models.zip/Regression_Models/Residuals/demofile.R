file.edit(fname)
source(fname, local=TRUE)
